({
  library(vroom)
  library(dplyr)
})
x <- vroom(
  file,
  id = "path",
  col_types = c(pickup_datetime = "c"),
  trim_ws = FALSE,
  quote = "",
  escape_double = FALSE,
  na = character(),
  altrep = FALSE
)
print(x)
a <- head(x)
b <- tail(x)
c <- sample_n(x, 100)
d <- filter(x, payment_type == "UNK")
e <- group_by(x, payment_type) %>% summarise(avg_tip = mean(tip_amount))
