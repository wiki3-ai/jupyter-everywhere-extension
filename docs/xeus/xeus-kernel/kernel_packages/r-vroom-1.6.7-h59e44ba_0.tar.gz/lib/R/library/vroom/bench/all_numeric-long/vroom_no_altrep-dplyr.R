({
  library(vroom)
  library(dplyr)
})
x <- vroom(
  file,
  trim_ws = FALSE,
  quote = "",
  escape_double = FALSE,
  na = character(),
  altrep = FALSE
)
print(x)
a <- head(x)
b <- tail(x)
c <- sample_n(x, 100)
d <- filter(x, X1 > 3)
e <- group_by(x, as.integer(X2)) %>% summarise(avg_X1 = mean(X1))
