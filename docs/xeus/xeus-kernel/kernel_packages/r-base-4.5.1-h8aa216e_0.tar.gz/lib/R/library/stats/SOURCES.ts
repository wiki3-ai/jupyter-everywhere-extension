package bats by
Martyn Plummer <plummer@iarc.fr>,
Paul Gilbert <pgilbert@bank-banque-canada.ca>

package tseries and ar.ols by
Adrian Trapletti <A.Trapletti@ci.tuwien.ac.at>

stl code on netlib, presumably by the authors of 

     R.B. Cleveland, W.S. Cleveland, J.E. McRae, and I. Terpenning,
     STL: A Seasonal-Trend Decomposition Procedure Based on Loess, 
     Statistics Research Report, AT&T Bell Laboratories.

Fortran package ts by B.D. Ripley, 1977--82, including starma.c which is
based on Applied Statistics Algorithm AS154 and AS182.


